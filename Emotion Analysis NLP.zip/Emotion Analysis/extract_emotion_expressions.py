# this aims to count the various emotions in each lines of text

import sys
import jieba
import pickle
import pathlib
import re
from nltk import FreqDist as fd

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_tuple(file,t):
    outfile = open(file, 'w', encoding='utf-8')
    for w,f in t:
        outfile.write(w + '\t' + str(f) + '\n')
    outfile.close()

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()


input_file = "COVID19_title_false_annotated_final.txt"
mylines = load_content(input_file)

Like = []
Happiness = []
Sadness = []
Anger = []
Fear = []
Disgust = []
Surprise = []
for line in mylines:
    words = line.split(' ')
    for word in words:
        if word.find('_like') > -1:
            w = word.split('_')
            Like.append(w[0])
        elif word.find('_happiness') > -1:
            w = word.split('_')
            Happiness.append(w[0])
        elif word.find('_sadness') > -1:
            w = word.split('_')
            Sadness.append(w[0])
        elif word.find('_anger') > -1:
            w = word.split('_')
            Anger.append(w[0])
        elif word.find('_fear') > -1:
            w = word.split('_')
            Fear.append(w[0])
        elif word.find('_disgust') > -1:
            w = word.split('_')
            Disgust.append(w[0])
        elif word.find('_surprise') > -1:
            w = word.split('_')
            Surprise.append(w[0])
        else: pass

like_fd = fd(Like)
like_fd_sorted = like_fd.most_common()

happiness_fd = fd(Happiness)
happiness_fd_sorted = happiness_fd.most_common()

sadness_fd = fd(Sadness)
sadness_fd_sorted = sadness_fd.most_common()

anger_fd = fd(Anger)
anger_fd_sorted = anger_fd.most_common()

fear_fd = fd(Fear)
fear_fd_sorted = fear_fd.most_common()

disgust_fd = fd(Disgust)
disgust_fd_sorted = disgust_fd.most_common()

surprise_fd = fd(Surprise)
surprise_fd_sorted = surprise_fd.most_common()

output_file1 = "COVID19 specific emotion expressions\\COVID19_title_false_like_expressions.txt"
write_tuple(output_file1,like_fd_sorted)

output_file2 = "COVID19 specific emotion expressions\\COVID19_title_false_happiness_expressions.txt"
write_tuple(output_file2,happiness_fd_sorted)

output_file3 = "COVID19 specific emotion expressions\\COVID19_title_false_sadness_expressions.txt"
write_tuple(output_file3,sadness_fd_sorted)

output_file4 = "COVID19 specific emotion expressions\\COVID19_title_false_anger_expressions.txt"
write_tuple(output_file4,anger_fd_sorted)

output_file5 = "COVID19 specific emotion expressions\\COVID19_title_false_fear_expressions.txt"
write_tuple(output_file5,fear_fd_sorted)

output_file6 = "COVID19 specific emotion expressions\\COVID19_title_false_disgust_expressions.txt"
write_tuple(output_file6,disgust_fd_sorted)

output_file7 = "COVID19 specific emotion expressions\\COVID19_title_false_surprise_expressions.txt"
write_tuple(output_file7,surprise_fd_sorted)

print("done.")


