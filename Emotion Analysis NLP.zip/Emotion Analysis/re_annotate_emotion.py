import sys
import jieba
import pickle
import pathlib
import re
import random

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

def read_dict(path):
    f = open(path, 'r', encoding='utf-8')
    mywords = f.readlines()
    newwords = []
    for w in mywords:
        newwords.append(w.strip('\n'))
    f.close()
    return newwords

def emotion_count(text):
    wordnum, hao, le, ai, nu, ju, wu, jing = 0, 0, 0, 0, 0, 0, 0, 0
    # sentences = len(re.split('[\.。！!？\?\n;；]+', text))
    words = jieba.lcut(text)
    wordnum = len(words)
    w_label = []
    for w in words:
        if w in Like_dic:
            hao += 1
            w_label.append(w+'_like')
        elif w in Happiness_dic:
            le += 1
            w_label.append(w + '_happiness')
        elif w in Sadness_dic:
            ai += 1
            w_label.append(w + '_sadness')
        elif w in Anger_dic:
            nu += 1
            w_label.append(w + '_anger')
        elif w in Fear_dic:
            ju += 1
            w_label.append(w + '_fear')
        elif w in Disgust_dic:
            wu += 1
            w_label.append(w + '_disgust')
        elif w in Surprise_dic:
            jing += 1
            w_label.append(w + '_surprise')
        else:
            w_label.append(w)
            pass
    annotated = ' '.join(w_label)
    result = {'annotation': annotated, 'words': wordnum, '好': hao, '乐': le, '哀': ai, '怒': nu, '惧': ju, '恶': wu, '惊': jing}
    return result

Like_dic = read_dict('merged emotion lexicon\\like_expressions_dedup.txt')
Happiness_dic = read_dict('merged emotion lexicon\\happiness_expressions_dedup.txt')
Surprise_dic = read_dict('merged emotion lexicon\\surprise_expressions_dedup.txt')
Fear_dic = read_dict('merged emotion lexicon\\fear_expressions_dedup.txt')
Anger_dic = read_dict('merged emotion lexicon\\anger_expressions_dedup.txt')
Disgust_dic = read_dict('merged emotion lexicon\\disgust_expressions_dedup.txt')
Sadness_dic = read_dict('merged emotion lexicon\\sadness_expressions_dedup.txt')

#print(Like_dic[:10]) #['险峰', '才高气清', '爱怜', '辨物居方', '兴味', '推乾就湿', '沉毅', '拱服', '笔大如椽', '高档']

#test
#test_text = "意大利科学家：#新冠病毒可能破坏血红蛋白#，阻止氧气送达全身"
#print(emotion_count(test_text)) #{'annotation': '意大利 科学家 ： # 新冠 病毒_fear 可能 破坏 血红蛋白 # ， 阻止 氧气 送达 全身', 'words': 15, '好': 0, '乐': 0, '哀': 0, '怒': 0, '惧': 1, '恶': 0, '惊': 0}

input_path = "COVID19_title_false_supplement.txt"
#input_path = "COVID19_title_true.txt"
mytext = load_content(input_path)

emotion_annotated = []

for line in mytext:
    emotion_label_dic = emotion_count(line)
    emotion_line = ""
    for x, y in emotion_label_dic.items():
        emotion_line += str(y) + "\t"
    emotion_annotated.append(emotion_line)

output_path = "COVID19_title_false_emotion_supplement.txt"
#output_path = "COVID19_title_true_emotion.txt"
write_text(output_path,emotion_annotated)

'''
# randomly select 401 lines
seq = [i for i in range(len(emotion_annotated))]
random_index = random.sample(seq, 401)
mysamples = []
for x in random_index:
    mysamples.append(emotion_annotated[x])

sample_path = "COVID19_title_true_emotion_samples.txt"
write_text(sample_path,mysamples)
'''

print("done.")




