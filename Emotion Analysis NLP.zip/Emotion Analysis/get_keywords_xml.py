from bs4 import BeautifulSoup

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

# Reading the data inside the xml
# file to a variable under the name
# data
with open('NLPCC2014\\NLPCC2014微博情绪分析样例数据.xml', 'r', encoding="utf8") as f:
	data = f.read()

# Passing the stored data inside
# the beautifulsoup parser, storing
# the returned object
Bs_data = BeautifulSoup(data, "xml")

# Using find() to extract attributes
# of the first instance of the tag
surprise_sent1 = Bs_data.find_all('sentence', {'emotion-1-type':'surprise'})
surprise_sent2 = Bs_data.find_all('sentence', {'emotion-2-type':'surprise'})

surprise_keywords  = []
for x in surprise_sent1:
	surprise_keywords.append(x.get('keyexpression1'))

for y in surprise_sent2:
	surprise_keywords.append(y.get('keyexpression1'))

surprise_keywords=set(surprise_keywords)
surprise_keywords.remove('null')

#print(surprise_keywords)
surprise_keywords_outfile = "NLPCC2014\\surprise_keywords.txt"
write_text(surprise_keywords_outfile,surprise_keywords)

print("done.")

# Extracting the data stored in a
# specific attribute of the
# `child` tag
#value = b_name.get('test')

#print(value)
