# to extract all sentences with fear

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

def check_fear(line):
    temp = line.split('\t')
    fear = temp[7]
    if int(fear) > 0:
        return 1
    else:
        return 0


#input_file_path = "COVID19_title_false_emotion.txt"
input_file_path = "COVID19_title_true_emotion.txt"
my_lines = load_content(input_file_path)

#print(my_lines[:10]) # ['CDC篡改死亡数据！最新数据：美新冠死亡率只有6％！14％老美存款已用光！\t22\t4\t1\t0\t0\t0\t0\t1\t0\t',...
                     # 10 \t in one line, no. 8 is fear

#print(check_fear(my_lines[0]))
fear_lines = []
other_lines = []
for line in my_lines:
    if check_fear(line)==1:
        fear_lines.append(line)
    else:
        other_lines.append(line)

#print(fear_lines[:2])
#print(len(fear_lines))#109

fear_out_path = "fear_headlines_covid19_true.txt"
non_fear_out_path = "non_fear_headlines_covid19_true.txt"
write_text(fear_out_path,fear_lines)
write_text(non_fear_out_path,other_lines)
print("done.")
