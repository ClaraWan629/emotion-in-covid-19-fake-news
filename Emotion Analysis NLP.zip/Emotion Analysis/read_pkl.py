# read pkl files of the emotion dictionaries in cnsenti

import pickle

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(str(line)+'\n')
    outfile.close()

# load : get the data from file
data = pickle.load(open("cnsenti_emotion_lexicon\\惧.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\\好.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\乐.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\惊.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\恶.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\哀.pkl", "rb"))
#data = pickle.load(open("cnsenti_emotion_lexicon\怒.pkl", "rb"))

out_file = "cnsenti_emotion_lexicon\\fear_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\like_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\happiness_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\surprise_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\disgust_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\sadness_dic.txt"
#out_file = "cnsenti_emotion_lexicon\\anger_dic.txt"
write_text(out_file,data)

print("done.")