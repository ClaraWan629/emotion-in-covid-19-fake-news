from nltk import FreqDist as fd

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_tuple(file,t):
    outfile = open(file, 'w', encoding='utf-8')
    for w,f in t:
        outfile.write(w + '\t' + str(f) + '\n')
    outfile.close()

input_file = "topic.txt"
topics = load_content(input_file)

topic_fd = fd(topics)
topic_fd_sorted = topic_fd.most_common()

output_file = "topic_fd.txt"
write_tuple(output_file,topic_fd_sorted)

print("done.")
