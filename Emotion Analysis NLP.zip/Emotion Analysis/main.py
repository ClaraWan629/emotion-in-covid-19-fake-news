# Conduct emotion analysis on Chinese texts
# use the cnsenti package https://github.com/hidadeng/cnsenti 使用大连理工大学情感本体库词典，支持七种情绪统计(好、乐、哀、怒、惧、恶、惊)。
# script adapted by Clara Mingyu Wan
# 6 Dec 2021

'''
# 中文文本情感统计
from cnsenti import Sentiment

senti = Sentiment()
test_text= '我好开心啊，非常非常非常高兴！今天我得了一百分，我很兴奋开心，愉快，开心'
result = senti.sentiment_count(test_text)
print(result) #{'words': 22, 'sentences': 2, 'pos': 4, 'neg': 0}


# test
senti = Sentiment()
emotion = Emotion()
test_text = '吃香蕉会得新型冠状病毒肺炎,有点郁闷！'

result_emo = emotion.emotion_count(test_text)
result_sent = senti.sentiment_count(test_text)
print(result_emo)
# {'words': 10, 'sentences': 2, '好': 0, '乐': 0, '哀': 1, '怒': 0, '惧': 0, '恶': 0, '惊': 0}
print(result_sent)
# {'words': 10, 'sentences': 1, 'pos': 0, 'neg': 1}
'''
import sys

# 中文文本情绪统计
from cnsenti import Emotion
from cnsenti import Sentiment

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

senti = Sentiment()
emotion = Emotion()

#input_path_false = "General_blog_false.txt"
#false_headlines = load_content(input_path_false)

input_path_true = "General_blog_true.txt"
true_headlines = load_content(input_path_true)

emotion_new_line = []
sent_new_line = []

#for line in false_headlines:
for line in true_headlines:
    result_emo = emotion.emotion_count(line)
    result_sent = senti.sentiment_count(line)
    emotion_line = ""
    sent_line = ""
    for x, y in result_emo.items():
        emotion_line += str(y) + "\t"
    for i, j in result_sent.items():
        sent_line += str(j) + "\t"

    emotion_new_line.append(line + "\t" + emotion_line)
    sent_new_line.append(line + "\t" + sent_line)

# print(emotion_new_line[100]) #白酒放冰箱冷冻室能制作75%的酒精 9 	1	0	0	0	0	0	0	0
# print(sent_new_line[100]) #白酒放冰箱冷冻室能制作75%的酒精 9	1	0	0	0	0	0	0	0

# write file
#false_out_path_emotion ="General_blog_false_emotion.txt"
#false_out_path_sentiment ="General_blog_false_sentiment.txt"

#write_text(false_out_path_emotion, emotion_new_line)
#write_text(false_out_path_sentiment, sent_new_line)

true_out_path_emotion ="General_blog_true_emotion.txt"
true_out_path_sentiment ="General_blog_true_sentiment.txt"

write_text(true_out_path_emotion, emotion_new_line)
write_text(true_out_path_sentiment, sent_new_line)

print("done.")