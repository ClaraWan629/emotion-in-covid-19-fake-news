# this script aims to clean the raw data
# deduplicate, separate title from Microblog
# Clara

import sys
import re

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

def deduplicate(text):
    new_line = []
    for line in text:
        if line not in new_line:
            new_line.append(line)
    return  new_line

def get_title(text):
    title = []
    for line in text:
        if line.find("【") > -1:
            newline = re.split('[【】\t]',line) #re.split allows multiple delimiters
            title.append(newline[1]+'\t'+newline[-1])
        elif len(line)> 6 and len(line) <=30:
            title.append(line)
    return title

def get_blog(text):
    blog = []
    for line in text:
        if line.find("【") > -1:
            newline = re.split('[【】\t]',line) #re.split allows multiple delimiters
            temp = newline[2]+'\t'+newline[-1]
            if len(temp) > 30:
                blog.append(temp)
        elif len(line) > 30:
            blog.append(line)
    return blog

input_path = "merged emotion lexicon\\disgust expressions.txt"
mytext = load_content(input_path)

disgust_expressions = deduplicate(mytext)
output_path = "merged emotion lexicon\\disgust_expressions_dedup.txt"

write_text(output_path,disgust_expressions)
print("done.")

'''
input_path = "CHECKED.txt"
mytext = load_content(input_path)

mytitles = get_title(mytext)
mytitles_new = deduplicate(mytitles)

out_path1 = "CHECKED_titles.txt"
write_text(out_path1, mytitles_new)
print("titles are extracted.")

myblog = get_blog(mytext)
myblog_new = deduplicate(myblog)

out_path2 = "CHECKED_blogs.txt"
write_text(out_path2, myblog_new)
print("blogs are extracted.")

## deduplicate
#dedup_text = deduplicate(mytext)
#print(len(dedup_text)) #2109
#print(dedup_text[:10])

#out_path = "CHECKED_deduplicate.txt"
#write_text(out_path, dedup_text)
test_text = ["【#美国新冠肺炎确诊超498万#】据美国约翰斯·霍普金斯大学发布的全球新冠肺炎数据实时统计系统，截至美国东部时间8月8日晚6时，全美共报告新冠肺炎确诊4986345例，死亡162244例。过去24小时，美国新增确诊67418例，新增死亡1507例。（人民日报记者张梦旭） 	real","【那栋整栋着火的是：广州南岸腾龙国际，女的在家里喷洒酒精消毒，男的在厨房做饭，家里就爆炸了，疫情防控期间，大家对酒精一定要先了解再去安全使用 切记！切记！】（来自 @一点资讯）O网页链接 	fake", "【部署战“疫”，习近平这些话直击要害】转发学习！ 	real"]

## get the titles
#my_titles = get_title(test_text)
#print(my_titles)

title = []

for line in test_text:
    if len(line) <= 20:
        title.append(line)
    elif line.find("【") > -1:
        newline = re.split('[【】]',line)
        title.append(newline[1])
print(title)
'''
