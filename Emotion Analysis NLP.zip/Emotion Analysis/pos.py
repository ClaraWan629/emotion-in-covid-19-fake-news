import sys
import jieba
import jieba.posseg as pseg
import pickle


#test
#words = pseg.cut("我爱北京天安门") #jieba默认模式
#jieba.enable_paddle() #启动paddle模式。 0.40版之后开始支持，早期版本不支持
#words = pseg.cut("我爱北京天安门",use_paddle=True) #paddle模式
#for word, flag in words:
    #print('%s %s' % (word, flag))

# 我 r
# 爱 v
# 北京 ns
# 天安门 ns

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

#input_file = "fear_headlines_covid19_false.txt"
#mytext = load_content(input_file)

# load : get the data from file
#data = pickle.load(open("惧.pkl", "rb"))
data = pickle.load(open("好.pkl", "rb"))
#print(type(data))
#print(len(data)) #1176

#out_file = "fear_dic.txt"
out_file = "like_dic.txt"
write_text(out_file,data)

print("done.")