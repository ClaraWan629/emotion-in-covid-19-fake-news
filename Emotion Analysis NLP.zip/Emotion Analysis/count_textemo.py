# this aims to count the various emotions in each lines of text

import sys
import jieba
import pickle
import pathlib
import re

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()


input_file = "COVID19_title_false_annotated_final.txt"
mylines = load_content(input_file)

emotion_lines = []
for line in mylines:
    Like = 0
    Happiness = 0
    Sadness = 0
    Anger = 0
    Fear = 0
    Disgust = 0
    Surprise = 0
    words = re.split('[ _]',line)
    w_len = len(words)
    for word in words:
        if word == 'like':
            Like += 1
        elif word == 'happiness':
            Happiness += 1
        elif word == 'sadness':
            Sadness += 1
        elif word == 'anger':
            Anger += 1
        elif word == 'fear':
            Fear += 1
        elif word == 'disgust':
            Disgust += 1
        elif word == 'surprise':
            Surprise += 1
        else: pass

    emotion_line = str(w_len) + '\t' + str(Like) + '\t' + str(Happiness) + '\t' + str(Sadness) + '\t' \
                   + str(Anger) + '\t' + str(Fear) + '\t' + str(Disgust) + '\t' + str(Surprise)

    emotion_lines.append(emotion_line)

#print(len(emotion_lines)) #401
#print(emotion_lines[:2]) #['0\t0\t0\t0\t2\t1\t0', '0\t0\t0\t0\t2\t1\t0']

output_file = "COVID19_title_false_emotion_counts.txt"
write_text(output_file,emotion_lines)

print("done.")


