# this script aims to clean the raw data of EANN-KDD18
# extract blogs from the raw data
# Clara

import sys
import re

def load_content(path):
    f = open(path, 'r', encoding='utf-8')
    text = f.readlines()
    mytext = []
    for x in text:
        mytext.append(x.strip('\n'))
    f.close()
    return mytext

def write_text(file, content):
    outfile = open(file, 'w', encoding='utf-8')
    for line in content:
        outfile.write(line+'\n')
    outfile.close()

def deduplicate(text):
    new_line = []
    for line in text:
        if line not in new_line:
            new_line.append(line)
    return  new_line

def is_chinese(character):
    value = 0
    if 0x4e00 < ord(character) < 0x9fff:
        value = 1
    else: value = 0
    return value

#input_path = "EANN-KDD18\\test_rumor.txt"
#input_path = "EANN-KDD18\\test_nonrumor.txt"
#input_path = "EANN-KDD18\\train_nonrumor.txt"
input_path = "EANN-KDD18\\train_rumor.txt"

mytext = load_content(input_path)

blogs = []

for line in mytext:
    has_Chinese = 0
    i = 0
    for ch in line:
        has_Chinese += is_chinese(ch)
        if i<5 and has_Chinese > 0:
            if len(line) > 8:
                blogs.append(line)
            break
        i += 1

## deduplicate
dedup_text = deduplicate(blogs)
#out_path = "EANN-KDD18\\test_rumor_blogs.txt"
#out_path = "EANN-KDD18\\test_nonrumor_blogs.txt"
#out_path = "EANN-KDD18\\train_nonrumor_blogs.txt"
out_path = "EANN-KDD18\\train_rumor_blogs.txt"

write_text(out_path, dedup_text)

print("done.")